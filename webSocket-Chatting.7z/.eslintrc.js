module.exports = {
  extends: ['airbnb-base', 'plugin:node/recommended', 'prettier'],
}
